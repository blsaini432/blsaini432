﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;
using BLL;
using System.Configuration;
using System.Net;

public partial class adminlogin : System.Web.UI.Page
{
    #region Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            HttpBrowserCapabilities httpBrowser = Request.Browser;
            bool enableJavascript = httpBrowser.JavaScript;
            if (enableJavascript == true)
            {
                loaddata(2);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Your Must enabled javascript from your browser !!');", true);
            }
        }
    }
    #endregion

    #region Events
    protected void btn_login_Click(object sender, EventArgs e)
    {
        try
        {
            HttpBrowserCapabilities httpBrowser = Request.Browser;
            bool enableJavascript = httpBrowser.JavaScript;
            if (enableJavascript == true)
            {

                if (txt_username.Text != "" && txt_userpassword.Text != "")
                {
                    List<ParmList> _lstparm = new List<ParmList>();
                    _lstparm.Add(new ParmList() { name = "@LoginID", value = txt_username.Text.Trim() });
                    _lstparm.Add(new ParmList() { name = "@Password", value = txt_userpassword.Text.Trim() });
                    _lstparm.Add(new ParmList() { name = "@Action", value = "LoginEmployee" });
                    cls_connection cls = new cls_connection();
                    DataTable dt = cls.select_data_dtNew("Proc_UniversalLogin ", _lstparm);
                    if (dt.Rows.Count > 0)
                    {
                        string ip = dt.Rows[0]["LastLoginIP"].ToString();
                        string email = dt.Rows[0]["email"].ToString();
                        string mobile = dt.Rows[0]["mobile"].ToString();
                        string EmployeeName = dt.Rows[0]["EmployeeName"].ToString();
                        if (ip != Request.UserHostAddress)
                        {
                            int otp = genraterandom();
                            sendsms(mobile, EmployeeName, otp);
                            Session["OTP"] = otp;
                            divlogin.Visible = false;
                            divotp.Visible = true;
                            sendemail(email, Convert.ToString(otp));
                            Session["OTP"] = otp;
                            divlogin.Visible = false;
                            divotp.Visible = true;
                            Session.Add("dtEmployee", dt);
                            Session.Add("EmployeeID", dt.Rows[0]["EmployeeID"].ToString());

                        }
                        else
                        {
                            InsertEmployeeLoginDetail(Convert.ToInt32(dt.Rows[0]["EmployeeID"].ToString()));
                            UpdateEmployeeLastLogin(Convert.ToInt32(dt.Rows[0]["EmployeeID"].ToString()));
                            Session.Add("dtEmployee", dt);
                            Session.Add("EmployeeID", dt.Rows[0]["EmployeeID"].ToString());
                            Response.Redirect("~/Root/Administrator/DashBoard.aspx");
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Your Account is not active. Please Contact to administrator !!');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Please Enter Valid Data');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Your Must enabled javascript from your browser !!');", true);
            }
        }
        catch(Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert("+ ex.ToString()+ ");", true);
        }
    }
    #endregion

    #region Utility Functions

    public void loaddata(int ID)
    {
        List<ParmList> _lstparm = new List<ParmList>();
        _lstparm.Add(new ParmList() { name = "@ID", value = ID });
        _lstparm.Add(new ParmList() { name = "@Action", value = "GetAll" });
        cls_connection cls = new cls_connection();
        DataTable dtCompany = cls.select_data_dtNew("Proc_ManageCompany ", _lstparm);
        if(dtCompany.Rows.Count > 0)
        {
            imglogo.ImageUrl = string.IsNullOrEmpty(Convert.ToString(dtCompany.Rows[0]["companylogo"])) ? "../../Uploads/User/Profile/dummy.png" : "../../Uploads/Company/Logo/actual/" + Convert.ToString(dtCompany.Rows[0]["companylogo"]);
            imglogo.AlternateText = dtCompany.Rows[0]["CompanyName"].ToString();
            lblCopyright.Text = dtCompany.Rows[0]["Copyright"].ToString();
          
        }
    }

    public int genraterandom()
    {
        Random random = new Random();
        int SixDigit = random.Next(1000, 9999);
        return SixDigit;
    }
    public int sendsms(string mobile, string empname, int otp)
    {
        int i = 0;
        string[] valueArray = new string[2];
        valueArray[0] = empname;
        valueArray[1] = otp.ToString();
        SMS.SendWithVar(mobile, 21, valueArray, 0);
        return i;
    }

    public static void sendemail(string email, string password)
    {
        try
        {
            string[] valueArray = new string[1];
            valueArray[0] = password;
            FlexiMail objSendMail = new FlexiMail();
            objSendMail.To = email;
            objSendMail.CC = "";
            objSendMail.BCC = "support@srdealonline.com";
            objSendMail.From = Convert.ToString(ConfigurationManager.AppSettings["mailFrom"]);
            objSendMail.FromName = "OTP From Admin";
            objSendMail.MailBodyManualSupply = false;
            objSendMail.EmailTemplateFileName = "Code.htm";
            objSendMail.Subject = "OTP For Login admin account";
            objSendMail.ValueArray = valueArray;
            objSendMail.Send();
        }
        catch (Exception ex)
        {

        }
    }

    private void InsertEmployeeLoginDetail(int EmployeeID)
    {
        Int32 intresult = 0;
        clsEmployeeLoginDetail objEmployeeLoginDetail = new clsEmployeeLoginDetail();
        intresult = objEmployeeLoginDetail.AddEditEmployeeLoginDetail(0, Convert.ToString(Request.UserHostAddress), EmployeeID);
    }

    private void UpdateEmployeeLastLogin(int EmployeeID)
    {
        cls_Universal objUniversal = new cls_Universal();
        objUniversal.UpdateLastLogin("UpdateEmployeeLastLogin", EmployeeID, Convert.ToString(Request.UserHostAddress));
    }
    #endregion

    protected void btn_LoginVerify_Click(object sender, EventArgs e)
    {
        try
        {
            HttpBrowserCapabilities httpBrowser = Request.Browser;
            bool enableJavascript = httpBrowser.JavaScript;
            if (enableJavascript == true)
            {

                if (txt_otp.Text != "")
                {
                    if (txt_otp.Text == Convert.ToString(Session["OTP"]))
                    {
                        Session["OTP"] = null;
                        InsertEmployeeLoginDetail(Convert.ToInt32(Session["EmployeeID"]));
                        UpdateEmployeeLastLogin(Convert.ToInt32(Session["EmployeeID"]));
                        Response.Redirect("~/Root/Administrator/DashBoard.aspx");
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Invalid OTP !!');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Enter OTP');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Your Must enabled javascript from your browser !!');", true);
            }
        }
        catch(Exception)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Some Error Occured !! Please Try Again');", true);
        }
    }

    protected void btn_forgot_Click(object sender, EventArgs e)
    {

    }
}