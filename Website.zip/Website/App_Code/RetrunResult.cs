﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RetrunResult
/// </summary>
public class RetrunResult
{
    public string Result { get; set; }
    public object Data { get; set; }
}